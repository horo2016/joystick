var maxProfit = function(prices) {
  var resultArray = [];
  for (let i = prices.length; )
}
const prices = [7, 1, 5, 3, 6, 4];
console.log(maxProfit(prices));